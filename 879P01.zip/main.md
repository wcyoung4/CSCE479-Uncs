# Introduction

Fashion-MNIST contains grayscale images from ten clothing categories and
gives a classification problem in which several classes, such as shirts,
T-shirts, pullovers, and coats, have similar visual structures.

This project evaluated how network architecture, learning rate, and
dropout regularization can affect connected neural network performance
on Fashion-MNIST. Two architectures, two learning rates, and two dropout
settings produced eight configurations. All of the models used ReLU
hidden-layer activations, a softmax output layer, categorical
cross-entropy loss, and Adam optimization. The 400--400 model with a
learning rate of $10^{-3}$ and dropout of 0.2 achieved the highest
validation accuracy of 90.18% and was selected for final analysis.

# Problem and Methods

The input to the classifier was a $28 \times 28$ grayscale Fashion-MNIST
image with pixel intensity values are integers ranging from 0 to 255.
Each image was assigned to one of ten output classes, which were
T-shirt/top, trouser, pullover, dress, coat, sandal, shirt, sneaker,
bag, or ankle boot. Pixel normalization was performed inside the network
by scaling the input values to the interval $[0,1]$. Class labels were
converted into ten-dimensional one-hot vectors, and categorical
cross-entropy was used as the loss function.

Two connected architectures were evaluated. The first architecture
contained two hidden layers each with 400 neurons, while the second
architecture contained only one hidden layer that had 128 neurons. All
hidden layers used ReLU activation. Each network used a ten-neuron
softmax output layer. The larger network was used to study if an
increased capacity improved the classification, while the smaller
architecture gave a lower-complexity comparison.

$10^{-3}$ and $10^{-4}$ learning rates were tested with dropout rates of
0 and 0.2. These produced eight total configurations. Adam was the
optimizer. The original training data were separated into 90% training
data and 10% validation data. Validation accuracy was used for model
selection. Early stopping monitored the validation loss with a patience
of four epochs and restored the weights from the best epoch.

# Experimental Results

The validation performance for all eight of the different configurations
studied for this project can be seen on
Table [1](#tab:results){reference-type="ref" reference="tab:results"}.
The 400--400 architecture with a learning rate of $10^{-3}$ and dropout
of 0.2 had the highest validation accuracy of the different
configurations, with a value of 90.18%.
Figure [1](#fig:learning){reference-type="ref" reference="fig:learning"}
shows the training and validation loss and accuracy. This shows both
convergence and overfitting behaviors.

::: {#tab:results}
   Architecture      LR       Dropout   Val. Acc.
  -------------- ----------- --------- ------------
     400--400     $10^{-3}$     0.2     **90.18%**
     400--400     $10^{-4}$     0.2       90.12%
       128        $10^{-4}$     0.2       89.77%
     400--400     $10^{-3}$     0.0       89.73%
     400--400     $10^{-4}$     0.0       89.65%
       128        $10^{-3}$     0.0       89.37%
       128        $10^{-3}$     0.2       89.28%
       128        $10^{-4}$     0.0       89.22%

  : Validation Accuracy for Experimental Configurations
:::

<figure id="fig:learning" data-latex-placement="!t">
<img src="./training_curves.png" style="width:88.0%" />
<figcaption>Training and validation cross-entropy loss and accuracy for
all eight experimental configurations. Faded lines represent training
results and solid lines represent validation results.</figcaption>
</figure>

The selected model had a test accuracy of 88.28% on the 10,000 test
examples. The estimated generalization error was 11.72%, the 95%
confidence interval was \[11.09%, 12.35%\], and the equivalent accuracy
interval was \[87.65%, 88.91%\].

Figure [2](#fig:confusion){reference-type="ref"
reference="fig:confusion"} shows the normalized confusion matrix for the
selected model. Bag, trouser, ankle boot, and sneaker were the most
accurate classes, with accuracies of 97.5%, 97.1%, 96.4%, and 95.9%
respectively. Shirt was the least accurate class, with an accuracy of
only 64.2%, and was often confused with the T-shirt/top class. Pullover
and coat also had lower accuracy ratings of 78.7% and 79.9%
respectively.

<figure id="fig:confusion" data-latex-placement="!t">
<img src="./confusion_matrix.png" />
<figcaption>Row-normalized confusion matrix for the selected
model.</figcaption>
</figure>

For the 400--400 model at $10^{-3}$, dropout reduced the
training-validation gap from 92.60%/89.73% to 91.00%/90.18%, suggesting
less overfitting. However, the 95% confidence intervals for the
test-error differences all contained zero.

Figure [3](#fig:saliency){reference-type="ref" reference="fig:saliency"}
shows prediction examples and gradient-times-input saliency maps.
Brighter regions show pixels with greater impact on the predicted class.
Important regions were usually located on the clothing item, especially
along boundaries and distinctive features. Misclassifications were
mostly found on visually similar classes such as shirts, T-shirts,
pullovers, and coats.

<figure id="fig:saliency" data-latex-placement="!t">
<img src="./saliency_examples_gradxinput.png" />
<figcaption>Example predictions with gradient-times-input saliency maps.
Brighter regions indicate pixels with greater influence on the
output.</figcaption>
</figure>

# Discussion

The larger 400--400 architecture had a higher validation accuracy than
the single 128-neuron architecture, which indicates that more model
capacity was useful for this specific task. Dropout improved the
validation accuracy in several configurations and reduced the difference
between training and validation performance for the selected model. The
learning rate also affected the performance, however there was no
learning rate that consistently was the best for all of the
configurations.

One of the main advantages of the connected approach that it is simple.
The networks are considerably straightforward for training and
evaluation. Also, dropout provides a simple form of regularization.
Saliency maps also provide a way to visualize where pixels most impact
the individual predictions. One of the disadvantages is that flattening
each image removes its unique two-dimensional spatial structure. This
likely impacts the accuracy for choosing between similar classes with
differences that depend on certain similar shapes.

# Conclusion

Two connected neural network architectures were evaluated on
Fashion-MNIST using different learning rates and dropout settings. The
400--400 architecture with a learning rate of $10^{-3}$ and dropout of
0.2 had the highest validation accuracy of 90.18% and was selected as
the best and final model. This model had a test accuracy of 88.28% with
an estimated generalization error of 11.72% and a 95% confidence
interval of \[11.09%, 12.35%\]. The results show that architecture size,
learning rate, and regularization influence generalization performance.
The remaining classification errors are concentrated mostly on visually
similar clothing categories.
