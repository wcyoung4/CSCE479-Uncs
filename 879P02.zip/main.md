# Introduction {#introduction .unnumbered}

CIFAR-100 presents a unique challenge in developing an accurate model
because it has 100 classes with only 500 training images per-class. Many
classes are difficult to differentiate (e.g., boy/man, maple/oak). The
goal of our project is to measure how architecture depth, learning rate,
and dropout each affect generalization. We use confidence intervals
alongside raw accuracy to evaluate model performance. From our
experiment, we observed our deep model to outperform the smaller model
by 17.7 points of top-1 accuracy reaching 62.4% top-1 and 88.1% top-5.

# Problem and Methods

The input to the CNN are 32 x 32 pixel images with 3 color channels in
batches of 64. Each image is classified into one of one hundred classes
(e.g. wolf, house, or bicycle). Each class also belongs to a superclass
such as large carnivores or large man-made outdoor things. The models
were trained and tested on the classes but superclass accuracy is also
reported by mapping each predicted class to its parent superclass. The
input image pixel values are scaled to the 0-1 range in the input layer
by dividing by the maximum pixel value of 255. Class labels were
converted into one-hot vectors and categorical cross-entropy was used as
the loss function. All networks used minor data augmentation during
training. The input images were randomly flipped horizontally and
randomly translated horizontally and vertically by up to 10% of the
image size (reflect fill). Augmentation was applied only to training
images.

Two CNN architectures were evaluated. The Small model (Table S1) has two
convolution pooling blocks with 32 and 64 filters, followed by a dense
layer of 256 nodes. The Deep model (Table I) contains three blocks with
two convolutions and batch normalization per block, with 64, 128, and
256 filters, followed by a dense layer of 512 nodes. Both models use
ReLU, dropout when $p=0.3$, and a 100-class softmax output.

All models were trained using Adam and L2 weight regularization
($\lambda=5\times10^{-4}$), following VGG \[2\]. L2 strength was fixed
to isolate the learning rate and dropout effects. Both architectures
were tested at learning rates $10^{-3}$ (Adam default) and $10^{-4}$,
and dropout rates $p=0$ and $p=0.3$, for eight configurations. The lower
learning rate tested more stable convergence, while the dropout rate
provided moderate regularization.

The 50,000 image training set was divided into 90% training and 10%
validation, which is the same as Fashion MNIST. The validation set was
used for early stopping with a patience parameter of 10 epochs (above
the required minimum of 5, because validation accuracy fluctuated
between epochs) and restored weights for the best model. Training and
validation loss and accuracy vs. epoch are plotted in Fig. S1. Final
top-1 and top-5 accuracies on the test set are reported in this paper.
We calculated 95% confidence intervals using the normal approximation
for individual generalization error rates and paired per-image error
differences for model comparisons ($n=10{,}000$).

# Experimental Results

The best Small CNN achieved 44.7% top-1 and 74.4% top-5 test accuracy at
learning rate $10^{-4}$ and dropout $p=0.3$. The best Deep CNN achieved
62.4% top-1 and 88.1% top-5 with the same settings. Its generalization
error was 0.376 (95% CI \[0.366, 0.385\]). The Deep model reduced the
error by 0.177 compared with Small (95% CI \[0.167, 0.187\]). Within the
Deep architecture, dropout reduced error by 0.034 (95% CI \[0.02,
0.04\]). All eight test results are reported in Table S2.

The best model had the highest prediction accuracy on the Trees
superclass (Fig. 1). For conciseness, the normalized confusion matrix
for the superclasses is presented here. See the Appendix for the
normalized 100 class confusion matrix (Fig. S3). The model had the most
confusion on similar superclasses such as confusing aquatic mammals and
fish or confusing large carnivores with medium mammals.

<figure id="fig:superclass" data-latex-placement="!htbp">
<img src="./confusion_matrix_superclass.png" />
<figcaption>Normalized confusion matrix for superclasses</figcaption>
</figure>

Motorcycle was the most accurate class (93%), whale the median (65%),
and seal the least accurate (17%, Table S3). Integrated Gradients (IG)
\[3\] were compared across these three classes. For each, we selected
the highest confidence correct prediction, lowest confidence correct
prediction, and highest confidence incorrect prediction, using maximum
softmax probability as confidence. In Fig. 2, attribution for correct
motorcycle predictions emphasized the motorcycle's surroundings or body,
whereas the incorrect prediction emphasized wheels and fairing and was
classified as bicycle. Similar border emphasis appears for whale and
seal (Figs. S4-S5).

The most confident misclassifications and selected IG maps appear in
Figs. S6-S7. In one example, a forest image was predicted as mountain,
with IG emphasizing the mountainous background. Another was a clock
predicted as telephone, had less interpretable attributions, potentially
influenced by the clock's wedge shape.

<figure id="fig:motorcycle" data-latex-placement="!htbp">
<img src="./ig_easiest_motorcycle.png" />
<figcaption>Integrated gradients for the easiest class for (left) high
confidence correct, (middle) low confidence correct, and (right) high
confidence incorrect</figcaption>
</figure>

# Discussion

Of the eight configurations, the VGG-inspired Deep CNN performed best.
At dropout $p=0.3$, lowering the learning rate from $10^{-3}$ to
$10^{-4}$ raised top-1 accuracy from 30.5% to 62.4%. Without dropout,
the improvement was smaller (57.1% to 59.0%). The high learning rate
Deep run with dropout struggled to converge, with training accuracy
below 25% (Fig. S1). This suggests difficulty with optimization rather
than overfitting in that configuration. At $10^{-4}$, dropout improved
top-1 accuracy from 59.0% to 62.4% and top-5 accuracy from 85.0% to
88.1%. These results suggest learning rate and dropout should be tuned
together. Further experiments could examine intermediate dropout rates,
architecture widths, and augmentation.

Fig. S1 shows overfitting in the Deep CNN without dropout at $10^{-4}$.
Training accuracy reached about 84% while validation accuracy plateaued
near 58%. Validation loss stopped improving after about epoch 35 even as
training loss continued to decline, indicating that further fitting did
not improve generalization. With dropout $p=0.3$, training accuracy fell
to 66% while test accuracy increased from 59.0% to 62.4%. Small models
showed smaller training-validation gaps (at most 6 points), suggesting
limited capacity. At $10^{-4}$, dropout changed the Small model's top-1
test accuracy only slightly, from 44.5% to 44.7%. At $10^{-3}$, adding
dropout reduced its accuracy from 44.4% to 40.0%.

Strengths include controlled comparisons, early stopping with restored
weights, and reporting confidence intervals, top-5 accuracy, normalized
confusion matrices, and IG maps. With 100 classes, top-5 accuracy
indicates whether the correct class is among the five highest-scoring
predictions. Limitations include one training run per configuration,
only two tested values per hyperparameter, and fixed L2 strength. Since
the Deep CNN introduced batch normalization alongside greater depth,
their effects can't be isolated.

# Conclusion

The 3-block VGG-style CNN with batch normalization outperformed the
Small CNN across the eight tested configurations. Learning rate and
dropout interacted a great deal: the Deep model with dropout at
$10^{-3}$ trained poorly, while dropout at $10^{-4}$ reduced overfitting
and improved test accuracy. The Small model seemed more capacity
limited. Errors often involved visually related classes, and Integrated
Gradients highlighted some plausible sources of confusion, such as
mountains in a forest image.

::: thebibliography
00 A. Krizhevsky, "Learning Multiple Layers of Features from Tiny
Images," Tech. Rep., Univ. of Toronto, 2009. K. Simonyan and A.
Zisserman, "Very Deep Convolutional Networks for Large-Scale Image
Recognition," Apr. 10, 2015, arXiv:1409.1556. doi:
10.48550/arXiv.1409.1556. M. Sundararajan, A. Taly, and Q. Yan,
"Axiomatic Attribution for Deep Networks," in Proc. 34th Int. Conf.
Mach. Learn. (ICML), 2017, pp. 3319--3328.
:::

# Appendix {#appendix .unnumbered}

::: tabularx
\|\>

p0.19\|Y\|

**Stage** & **Configuration**\
Input & RGB image, 32 x 32 x 3 (NHWC)\
Scaling & Rescaling(1/255), from 0-255 pixels to 0-1\
Augmentation & Horizontal flip; +/-10% H/W translation (reflect fill;
training only)\
Conv block 1 & 2 x \[Conv2D(64, 3x3, stride 1, same, bias=False)-\>
BatchNorm-\>ReLU\]-\>MaxPool2D(2x2, stride=2)-\> Dropout(d)\
Conv block 2 & 2 x \[Conv2D(128, 3x3, stride 1, same, bias=False)-\>
BatchNorm-\>ReLU\]-\>MaxPool2D(2x2, stride=2) -\> Dropout(d)\
Conv block 3 & 2 x \[Conv2D(256, 3x3, stride 1, same, bias=False) -\>
BatchNorm-\>ReLU\]-\>MaxPool2D(2x2, stride=2)-\> Dropout(d)\
Classifier & Flatten -\> Dense(512, ReLU) -\> Dropout(d)\
Output & Dense(100, Softmax)\
Regularization & L2 = 5e-04 on Conv2D and hidden Dense kernels; d in
{0.0, 0.3}; omit Dropout if d=0\
Defaults & Glorot-uniform kernels; zero-initialized biases; BatchNorm
momentum=0.99, epsilon=0.001\
:::

::: tabularx
\|\>

p0.19\|Y\|

**Stage** & **Configuration**\
Input & RGB image, 32 x 32 x 3 (NHWC)\
Scaling & Rescaling(1/255), from 0-255 pixels to 0-1\
Augmentation & Horizontal flip; +/-10% H/W translation (reflect fill;
training only)\
Conv block 1 & Conv2D(32, 3x3, stride 1, same, bias=True) -\> ReLU-\>
MaxPool2D(2x2, stride 2) -\> Dropout(d)\
Conv block 2 & Conv2D(64, 3x3, stride 1, same, bias=True) -\> ReLU-\>
MaxPool2D(2x2, stride 2) -\> Dropout(d)\
Classifier & Flatten -\> Dense(256, ReLU) -\> Dropout(d)\
Output & Dense(100, Softmax)\
Regularization & L2 = 5e-04 on Conv2D and hidden Dense kernels; d in
{0.0, 0.3}; omit Dropout if d=0\
Defaults & Glorot-uniform kernels; zero-initialized biases\
:::

::: {#tab:conditions}
  **Arch.**    **Learning Rate**   **Dropout**   **L2**    **Params**  **Best Epoch**   **Test Accuracy**   **Test Top5 Accuracy**
  ----------- ------------------- ------------- -------- ------------ ---------------- ------------------- ------------------------
  Deep              0.0001             0.3       0.0005       3297060        68              0.62449               0.88099
  Deep              0.0001              0        0.0005       3297060        36              0.59039               0.84950
  Deep               0.001              0        0.0005       3297060        41              0.57090               0.84399
  Deep               0.001             0.3       0.0005       3297060        23              0.30540               0.64880
  Small             0.0001             0.3       0.0005       1093924       135              0.44749               0.74419
  Small             0.0001              0        0.0005       1093924        91              0.44519               0.73299
  Small              0.001              0        0.0005       1093924        33              0.44359               0.74299
  Small              0.001             0.3       0.0005       1093924        31              0.40029               0.71289

  : Summary of Test Accuracy for Each Condition
:::

<figure data-latex-placement="!p">
<img src="./training_curves.png" style="height:78.0%" />
<figcaption>Loss and Accuracy vs. Training Epoch</figcaption>
</figure>

<figure data-latex-placement="!p">
<img src="./predictions.png" style="height:78.0%" />
<figcaption>Random accurate and inaccurate predictions from the test
set</figcaption>
</figure>

<figure data-latex-placement="!p">
<img src="./confusion_matrix.png" style="height:78.0%" />
<figcaption>Normalized confusion matrix for all 100 classes</figcaption>
</figure>

::: {#tab:perclass}
+---------------+--------------------------------+--------------+---------------+-------------+
| **Class**     | **Superclass**                 | **Accuracy** | **Most        | **Times     |
|               |                                |              | Confused      | Confused**  |
|               |                                |              | With:**       |             |
+:==============+:===============================+:============:+:==============+:===========:+
| *Table S3 (continued)*                                                                      |
+---------------+--------------------------------+--------------+---------------+-------------+
| **Class**     | **Superclass**                 | **Accuracy** | **Most        | **Times     |
|               |                                |              | Confused      | Confused**  |
|               |                                |              | With:**       |             |
+---------------+--------------------------------+--------------+---------------+-------------+
| apple         | fruit_and_vegetables           | 0.77         | orange        | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| aquarium_fish | fish                           | 0.79         | crab          | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| baby          | people                         | 0.45         | boy           | 13          |
+---------------+--------------------------------+--------------+---------------+-------------+
| bear          | large_carnivores               | 0.36         | beaver        | 13          |
+---------------+--------------------------------+--------------+---------------+-------------+
| beaver        | aquatic_mammals                | 0.57         | porcupine     | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| bed           | household_furniture            | 0.74         | couch         | 12          |
+---------------+--------------------------------+--------------+---------------+-------------+
| bee           | insects                        | 0.78         | beetle        | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| beetle        | insects                        | 0.63         | cockroach     | 15          |
+---------------+--------------------------------+--------------+---------------+-------------+
| bicycle       | vehicles_1                     | 0.83         | motorcycle    | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| bottle        | food_containers                | 0.66         | telephone     | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| bowl          | food_containers                | 0.52         | plate         | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| boy           | people                         | 0.38         | man           | 24          |
+---------------+--------------------------------+--------------+---------------+-------------+
| bridge        | large_man-made_outdoor_things  | 0.7          | forest        | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| bus           | vehicles_1                     | 0.66         | pickup_truck  | 9           |
+---------------+--------------------------------+--------------+---------------+-------------+
| butterfly     | insects                        | 0.63         | leopard       | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| camel         | large_omnivores_and_herbivores | 0.46         | cattle        | 10          |
+---------------+--------------------------------+--------------+---------------+-------------+
| can           | food_containers                | 0.61         | telephone     | 9           |
+---------------+--------------------------------+--------------+---------------+-------------+
| castle        | large_man-made_outdoor_things  | 0.79         | house         | 10          |
+---------------+--------------------------------+--------------+---------------+-------------+
| caterpillar   | insects                        | 0.48         | butterfly     | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| cattle        | large_omnivores_and_herbivores | 0.68         | fox           | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| chair         | household_furniture            | 0.87         | couch         | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| chimpanzee    | large_omnivores_and_herbivores | 0.79         | bear          | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| clock         | household_electrical_devices   | 0.61         | bowl          | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| cloud         | large_natural_outdoor_scenes   | 0.7          | sea           | 12          |
+---------------+--------------------------------+--------------+---------------+-------------+
| cockroach     | insects                        | 0.89         | beetle        | 2           |
+---------------+--------------------------------+--------------+---------------+-------------+
| couch         | household_furniture            | 0.48         | bed           | 20          |
+---------------+--------------------------------+--------------+---------------+-------------+
| crab          | non-insect_invertebrates       | 0.68         | lobster       | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| crocodile     | reptiles                       | 0.52         | leopard       | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| cup           | food_containers                | 0.74         | bowl          | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| dinosaur      | reptiles                       | 0.69         | crab          | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| dolphin       | aquatic_mammals                | 0.6          | shark         | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| elephant      | large_omnivores_and_herbivores | 0.55         | cattle        | 9           |
+---------------+--------------------------------+--------------+---------------+-------------+
| flatfish      | fish                           | 0.64         | ray           | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| forest        | large_natural_outdoor_scenes   | 0.62         | willow_tree   | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| fox           | medium_mammals                 | 0.73         | hamster       | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| girl          | people                         | 0.25         | woman         | 29          |
+---------------+--------------------------------+--------------+---------------+-------------+
| hamster       | small_mammals                  | 0.7          | fox           | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| house         | large_man-made_outdoor_things  | 0.63         | castle        | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| kangaroo      | large_omnivores_and_herbivores | 0.37         | fox           | 9           |
+---------------+--------------------------------+--------------+---------------+-------------+
| keyboard      | household_electrical_devices   | 0.87         | couch         | 2           |
+---------------+--------------------------------+--------------+---------------+-------------+
| lamp          | household_electrical_devices   | 0.58         | chair         | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| lawn_mower    | vehicles_2                     | 0.75         | motorcycle    | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| leopard       | large_carnivores               | 0.75         | shrew         | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| lion          | large_carnivores               | 0.57         | fox           | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| lizard        | reptiles                       | 0.2          | crab          | 8           |
+---------------+--------------------------------+--------------+---------------+-------------+
| lobster       | non-insect_invertebrates       | 0.6          | crab          | 10          |
+---------------+--------------------------------+--------------+---------------+-------------+
| man           | people                         | 0.46         | boy           | 17          |
+---------------+--------------------------------+--------------+---------------+-------------+
| maple_tree    | trees                          | 0.73         | oak_tree      | 21          |
+---------------+--------------------------------+--------------+---------------+-------------+
| motorcycle    | vehicles_1                     | 0.93         | bicycle       | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| mountain      | large_natural_outdoor_scenes   | 0.82         | whale         | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| mouse         | small_mammals                  | 0.24         | shrew         | 19          |
+---------------+--------------------------------+--------------+---------------+-------------+
| mushroom      | fruit_and_vegetables           | 0.65         | leopard       | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| oak_tree      | trees                          | 0.73         | maple_tree    | 21          |
+---------------+--------------------------------+--------------+---------------+-------------+
| orange        | fruit_and_vegetables           | 0.91         | aquarium_fish | 1           |
+---------------+--------------------------------+--------------+---------------+-------------+
| orchid        | flowers                        | 0.77         | butterfly     | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| otter         | aquatic_mammals                | 0.23         | beaver        | 16          |
+---------------+--------------------------------+--------------+---------------+-------------+
| palm_tree     | trees                          | 0.87         | maple_tree    | 2           |
+---------------+--------------------------------+--------------+---------------+-------------+
| pear          | fruit_and_vegetables           | 0.59         | orange        | 12          |
+---------------+--------------------------------+--------------+---------------+-------------+
| pickup_truck  | vehicles_1                     | 0.76         | bus           | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| pine_tree     | trees                          | 0.39         | oak_tree      | 26          |
+---------------+--------------------------------+--------------+---------------+-------------+
| plain         | large_natural_outdoor_scenes   | 0.86         | sea           | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| plate         | food_containers                | 0.62         | clock         | 16          |
+---------------+--------------------------------+--------------+---------------+-------------+
| poppy         | flowers                        | 0.67         | rose          | 13          |
+---------------+--------------------------------+--------------+---------------+-------------+
| porcupine     | medium_mammals                 | 0.67         | beaver        | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| possum        | medium_mammals                 | 0.32         | turtle        | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| rabbit        | small_mammals                  | 0.33         | porcupine     | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| raccoon       | medium_mammals                 | 0.55         | porcupine     | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| ray           | fish                           | 0.48         | shark         | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| road          | large_man-made_outdoor_things  | 0.85         | bridge        | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| rocket        | vehicles_2                     | 0.74         | bridge        | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| rose          | flowers                        | 0.68         | poppy         | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| sea           | large_natural_outdoor_scenes   | 0.8          | plain         | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| seal          | aquatic_mammals                | 0.17         | otter         | 12          |
+---------------+--------------------------------+--------------+---------------+-------------+
| shark         | fish                           | 0.53         | ray           | 8           |
+---------------+--------------------------------+--------------+---------------+-------------+
| shrew         | small_mammals                  | 0.52         | porcupine     | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+
| skunk         | medium_mammals                 | 0.8          | cattle        | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| skyscraper    | large_man-made_outdoor_things  | 0.79         | castle        | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| snail         | non-insect_invertebrates       | 0.55         | lizard        | 4           |
+---------------+--------------------------------+--------------+---------------+-------------+
| snake         | reptiles                       | 0.47         | crab          | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| spider        | non-insect_invertebrates       | 0.64         | bee           | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| squirrel      | small_mammals                  | 0.39         | fox           | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| streetcar     | vehicles_2                     | 0.69         | bus           | 13          |
+---------------+--------------------------------+--------------+---------------+-------------+
| sunflower     | flowers                        | 0.91         | rose          | 2           |
+---------------+--------------------------------+--------------+---------------+-------------+
| sweet_pepper  | fruit_and_vegetables           | 0.47         | orange        | 13          |
+---------------+--------------------------------+--------------+---------------+-------------+
| table         | household_furniture            | 0.57         | bed           | 14          |
+---------------+--------------------------------+--------------+---------------+-------------+
| tank          | vehicles_2                     | 0.76         | pickup_truck  | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| telephone     | household_electrical_devices   | 0.66         | clock         | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| television    | household_electrical_devices   | 0.71         | bed           | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| tiger         | large_carnivores               | 0.66         | fox           | 13          |
+---------------+--------------------------------+--------------+---------------+-------------+
| tractor       | vehicles_2                     | 0.75         | motorcycle    | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| train         | vehicles_1                     | 0.57         | streetcar     | 14          |
+---------------+--------------------------------+--------------+---------------+-------------+
| trout         | fish                           | 0.8          | lizard        | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| tulip         | flowers                        | 0.43         | poppy         | 14          |
+---------------+--------------------------------+--------------+---------------+-------------+
| turtle        | reptiles                       | 0.49         | beaver        | 5           |
+---------------+--------------------------------+--------------+---------------+-------------+
| wardrobe      | household_furniture            | 0.89         | television    | 3           |
+---------------+--------------------------------+--------------+---------------+-------------+
| whale         | aquatic_mammals                | 0.65         | shark         | 11          |
+---------------+--------------------------------+--------------+---------------+-------------+
| willow_tree   | trees                          | 0.43         | maple_tree    | 26          |
+---------------+--------------------------------+--------------+---------------+-------------+
| wolf          | large_carnivores               | 0.51         | leopard       | 6           |
+---------------+--------------------------------+--------------+---------------+-------------+
| woman         | people                         | 0.46         | man           | 16          |
+---------------+--------------------------------+--------------+---------------+-------------+
| worm          | non-insect_invertebrates       | 0.66         | snake         | 7           |
+---------------+--------------------------------+--------------+---------------+-------------+

: Summary of Class, Accuracy, and Most Confused Class
:::

<figure data-latex-placement="!p">
<img src="./ig_median_whale.png" style="height:80.0%" />
<figcaption>Integrated gradients for the median class for (left) high
confidence correct, (middle) low confidence correct, and (right) high
confidence incorrect</figcaption>
</figure>

<figure data-latex-placement="!p">
<img src="./ig_hardest_seal.png" style="height:80.0%" />
<figcaption>Integrated gradients for the hardest class for (left) high
confidence correct, (middle) low confidence correct, and (right) high
confidence incorrect</figcaption>
</figure>

<figure data-latex-placement="!p">
<img src="./misclassified.png" style="height:80.0%" />
<figcaption>Most confident misclassifications</figcaption>
</figure>

<figure data-latex-placement="!p">
<img src="./ig_confident_errors.png" style="height:80.0%" />
<figcaption>Integrated gradients for a subset of the most confident
misclassifications</figcaption>
</figure>
